아기 준비물 웹앱 - 올리는 방법

1. https://vercel.com 에 로그인합니다.
2. Add New → Project → 아래쪽 "Deploy without Git"(또는 폴더 끌어다 놓기)에서
   이 baby-prep-app 폴더를 통째로 올립니다. (GitHub 저장소에 올린 뒤 연결해도 됩니다.)
3. Framework Preset은 "Other", 빌드 설정은 비워 두고 Deploy를 누릅니다.
4. 생긴 주소(예: baby-prep.vercel.app)를 다른 사람에게 보내면 됩니다.

쓰는 사람은 링크를 열고
- 아이폰: Safari 공유 버튼 → "홈 화면에 추가"
- 안드로이드: 크롬 메뉴(⋮) → "홈 화면에 추가" / "앱 설치"

목록은 각자 폰 브라우저에 저장됩니다. 폰을 바꿀 땐 설정 → 백업 파일 저장/불러오기.
앱을 고쳐 다시 올릴 때는 sw.js 맨 위 VERSION 숫자를 올려 주세요(예: babyprep-v2).
기본 목록은 index.html 안의 TEMPLATE 부분에 들어 있습니다.
